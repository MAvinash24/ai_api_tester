'use client';

import { useState } from 'react';
import ApiTestForm from '@/components/api-test-form';
import TestResultDisplay from '@/components/test-result-display';
import type { TestResult } from '@/lib/types';

export default function DashboardPage() {
  const [testResult, setTestResult] = useState<TestResult | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleTestRun = (result: TestResult | null, error: string | null) => {
    setTestResult(result);
    setError(error);
  };

  return (
    <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-[1fr_2fr]">
      <div className="md:col-span-2 lg:col-span-1">
        <ApiTestForm
          onTestRun={handleTestRun}
          setIsLoading={setIsLoading}
          isLoading={isLoading}
        />
      </div>
      <div className="md:col-span-2 lg:col-span-1">
        <TestResultDisplay
          result={testResult}
          isLoading={isLoading}
          error={error}
        />
      </div>
    </div>
  );
}
