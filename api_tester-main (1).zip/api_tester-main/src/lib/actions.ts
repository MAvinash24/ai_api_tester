
'use server';

import { z } from 'zod';
import { analyzeApiResponseCorrectness } from '@/ai/flows/analyze-api-response-correctness';
import { generateApiDocumentation } from '@/ai/flows/generate-api-documentation';
import { explainTestFailure } from '@/ai/flows/explain-test-failures';
import type { TestResult } from './types';

const ApiTestInputSchema = z.object({
  method: z.string(),
  url: z.string().url({ message: 'Please enter a valid URL.' }),
  headers: z.string(),
  body: z.string(),
});

export async function runAndAnalyzeApiTest(
  input: z.infer<typeof ApiTestInputSchema>
): Promise<{ result: TestResult | null; error: string | null }> {
  const validatedInput = ApiTestInputSchema.safeParse(input);
  if (!validatedInput.success) {
    return { result: null, error: validatedInput.error.errors.map(e => e.message).join(', ') };
  }

  const { method, url, headers: headersString, body: bodyString } = validatedInput.data;

  try {
    const headers = JSON.parse(headersString) as Record<string, string>;
    const requestOptions: RequestInit = {
      method,
      headers: new Headers(headers),
      body: method !== 'GET' && method !== 'HEAD' && bodyString ? bodyString : undefined,
    };

    const startTime = performance.now();
    const response = await fetch(url, requestOptions);
    const endTime = performance.now();

    const responseTime = Math.round(endTime - startTime);
    const statusCode = response.status;
    const responseBody = await response.text();
    const responseHeaders: Record<string, string> = {};
    response.headers.forEach((value, key) => {
      responseHeaders[key] = value;
    });

    const requestData = {
      url,
      method,
      headers: headersString,
      body: bodyString,
    };
    
    // Run AI analysis in parallel
    const [aiAnalysis, aiDocs, aiFailureExplanation] = await Promise.all([
      analyzeApiResponseCorrectness({ statusCode, responseTime, responseBody }).catch(() => null),
      generateApiDocumentation(requestData).catch(() => null),
      !response.ok
        ? explainTestFailure({
            statusCode,
            responseBody,
            url,
            requestBody: bodyString,
            requestHeaders: headersString,
          }).catch(() => null)
        : Promise.resolve(null),
    ]);

    const result: TestResult = {
      id: crypto.randomUUID(),
      statusCode,
      responseTime,
      responseBody,
      responseHeaders,
      createdAt: new Date().toISOString(),
      request: requestData,
      aiAnalysis: aiAnalysis ?? undefined,
      aiDocs: aiDocs ?? undefined,
      aiFailureExplanation: aiFailureExplanation ?? undefined,
    };
    
    return { result, error: null };
  } catch (e) {
    const error = e instanceof Error ? e.message : 'An unknown error occurred.';
    console.error(error);
    return { result: null, error: `Failed to run test: ${error}` };
  }
}
