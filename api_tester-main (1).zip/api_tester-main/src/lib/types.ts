export type TestResult = {
  id: string;
  statusCode: number;
  responseTime: number;
  responseBody: string;
  responseHeaders: Record<string, string>;
  createdAt: string;
  aiAnalysis?: {
    analysisSummary: string;
    suggestedImprovements: string;
  };
  aiDocs?: {
    documentation: string;
    curlCommand: string;
  };
  aiFailureExplanation?: {
    explanation: string;
  };
  request: {
    url: string;
    method: string;
    headers?: string;
    body?: string;
  };
};
