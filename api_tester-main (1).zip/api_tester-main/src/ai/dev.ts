import { config } from 'dotenv';
config();

import '@/ai/flows/explain-test-failures.ts';
import '@/ai/flows/analyze-api-response-correctness.ts';
import '@/ai/flows/generate-api-documentation.ts';
import '@/ai/flows/suggest-improved-test-cases.ts';