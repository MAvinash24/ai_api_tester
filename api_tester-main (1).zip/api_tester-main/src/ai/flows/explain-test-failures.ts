'use server';

/**
 * @fileOverview A flow to explain test failures in natural language.
 *
 * - explainTestFailure - A function that explains the test failure.
 * - ExplainTestFailureInput - The input type for the explainTestFailure function.
 * - ExplainTestFailureOutput - The return type for the explainTestFailure function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const ExplainTestFailureInputSchema = z.object({
  statusCode: z.number().describe('The HTTP status code of the response.'),
  responseBody: z.string().describe('The body of the response.'),
  url: z.string().describe('The URL that was tested.'),
  requestBody: z.string().optional().describe('The request body, if any.'),
  requestHeaders: z.string().optional().describe('The request headers, if any.'),
});
export type ExplainTestFailureInput = z.infer<typeof ExplainTestFailureInputSchema>;

const ExplainTestFailureOutputSchema = z.object({
  explanation: z.string().describe('An explanation of the test failure in natural language.'),
});
export type ExplainTestFailureOutput = z.infer<typeof ExplainTestFailureOutputSchema>;

export async function explainTestFailure(input: ExplainTestFailureInput): Promise<ExplainTestFailureOutput> {
  return explainTestFailureFlow(input);
}

const prompt = ai.definePrompt({
  name: 'explainTestFailurePrompt',
  input: {schema: ExplainTestFailureInputSchema},
  output: {schema: ExplainTestFailureOutputSchema},
  prompt: `You are an AI agent that helps developers understand why their API tests are failing.

You are given the following information about a test:

URL: {{{url}}}
Status Code: {{{statusCode}}}
Response Body: {{{responseBody}}}

{{#if requestBody}}
Request Body: {{{requestBody}}}
{{/if}}

{{#if requestHeaders}}
Request Headers: {{{requestHeaders}}}
{{/if}}

Explain in natural language why the test might have failed. Be concise and focus on the most likely causes.
`,
});

const explainTestFailureFlow = ai.defineFlow(
  {
    name: 'explainTestFailureFlow',
    inputSchema: ExplainTestFailureInputSchema,
    outputSchema: ExplainTestFailureOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
