'use server';

/**
 * @fileOverview An AI agent for generating API documentation and cURL commands.
 *
 * - generateApiDocumentation - A function that generates API documentation and cURL commands.
 * - GenerateApiDocumentationInput - The input type for the generateApiDocumentation function.
 * - GenerateApiDocumentationOutput - The return type for the generateApiDocumentation function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const GenerateApiDocumentationInputSchema = z.object({
  method: z.string().describe('The HTTP method of the API endpoint (e.g., GET, POST, PUT, DELETE).'),
  url: z.string().describe('The URL of the API endpoint.'),
  headers: z.string().optional().describe('The headers of the API request (in JSON format).'),
  body: z.string().optional().describe('The body of the API request (in JSON format).'),
});
export type GenerateApiDocumentationInput = z.infer<
  typeof GenerateApiDocumentationInputSchema
>;

const GenerateApiDocumentationOutputSchema = z.object({
  documentation: z.string().describe('The generated API documentation.'),
  curlCommand: z.string().describe('The generated cURL command.'),
});
export type GenerateApiDocumentationOutput = z.infer<
  typeof GenerateApiDocumentationOutputSchema
>;

export async function generateApiDocumentation(
  input: GenerateApiDocumentationInput
): Promise<GenerateApiDocumentationOutput> {
  return generateApiDocumentationFlow(input);
}

const prompt = ai.definePrompt({
  name: 'generateApiDocumentationPrompt',
  input: {schema: GenerateApiDocumentationInputSchema},
  output: {schema: GenerateApiDocumentationOutputSchema},
  prompt: `You are an AI agent that generates API documentation and cURL commands for a given API endpoint.

  Given the following API endpoint information:
  Method: {{{method}}}
  URL: {{{url}}}
  Headers: {{{headers}}}
  Body: {{{body}}}

  Generate the API documentation, explaining the purpose, parameters, and expected response.
  Also, generate the corresponding cURL command to execute the API request.

  Ensure the cURL command includes all necessary headers and data.

  The documentation should be clear, concise, and easy to understand.
`,
});

const generateApiDocumentationFlow = ai.defineFlow(
  {
    name: 'generateApiDocumentationFlow',
    inputSchema: GenerateApiDocumentationInputSchema,
    outputSchema: GenerateApiDocumentationOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
