'use server';

/**
 * @fileOverview This file contains a Genkit flow that suggests improved test cases based on previous test results and API specifications.
 *
 * - suggestImprovedTestCases - A function that takes API test results and specifications as input and returns suggestions for improved test cases.
 * - SuggestImprovedTestCasesInput - The input type for the suggestImprovedTestCases function.
 * - SuggestImprovedTestCasesOutput - The return type for the suggestImprovedTestCases function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const SuggestImprovedTestCasesInputSchema = z.object({
  apiSpecification: z
    .string()
    .describe('The API specification in a format like OpenAPI or Swagger.'),
  previousTestResults: z
    .string()
    .describe(
      'The previous test results in JSON format, including status code, response time, and response body.'
    ),
});
export type SuggestImprovedTestCasesInput = z.infer<
  typeof SuggestImprovedTestCasesInputSchema
>;

const SuggestImprovedTestCasesOutputSchema = z.object({
  suggestedTestCases: z
    .string()
    .describe('Suggestions for improved test cases in plain English.'),
});
export type SuggestImprovedTestCasesOutput = z.infer<
  typeof SuggestImprovedTestCasesOutputSchema
>;

export async function suggestImprovedTestCases(
  input: SuggestImprovedTestCasesInput
): Promise<SuggestImprovedTestCasesOutput> {
  return suggestImprovedTestCasesFlow(input);
}

const prompt = ai.definePrompt({
  name: 'suggestImprovedTestCasesPrompt',
  input: {schema: SuggestImprovedTestCasesInputSchema},
  output: {schema: SuggestImprovedTestCasesOutputSchema},
  prompt: `You are an AI agent specializing in suggesting improved test cases for APIs.

  Based on the following API specification and previous test results, suggest improved test cases to increase test coverage and find edge cases more efficiently.

  API Specification:
  {{apiSpecification}}

  Previous Test Results:
  {{previousTestResults}}

  Provide your suggestions in plain English.
  `,
});

const suggestImprovedTestCasesFlow = ai.defineFlow(
  {
    name: 'suggestImprovedTestCasesFlow',
    inputSchema: SuggestImprovedTestCasesInputSchema,
    outputSchema: SuggestImprovedTestCasesOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
