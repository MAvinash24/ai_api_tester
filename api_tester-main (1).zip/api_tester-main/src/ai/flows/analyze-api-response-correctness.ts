'use server';
/**
 * @fileOverview Analyzes API responses for correctness, latency, and errors.
 *
 * - analyzeApiResponseCorrectness - A function that handles the API response analysis process.
 * - AnalyzeApiResponseCorrectnessInput - The input type for the analyzeApiResponseCorrectness function.
 * - AnalyzeApiResponseCorrectnessOutput - The return type for the analyzeApiResponseCorrectness function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const AnalyzeApiResponseCorrectnessInputSchema = z.object({
  statusCode: z.number().describe('The HTTP status code of the API response.'),
  responseTime: z.number().describe('The response time of the API in milliseconds.'),
  responseBody: z.string().describe('The body of the API response.'),
  expectedSchema: z.string().optional().describe('The expected schema of the API response, in JSON format.'),
});
export type AnalyzeApiResponseCorrectnessInput = z.infer<typeof AnalyzeApiResponseCorrectnessInputSchema>;

const AnalyzeApiResponseCorrectnessOutputSchema = z.object({
  analysisSummary: z.string().describe('A summary of the API response analysis, including correctness, latency, and errors.'),
  suggestedImprovements: z.string().describe('Suggestions for better error handling, improved test payloads, or missing headers.'),
});
export type AnalyzeApiResponseCorrectnessOutput = z.infer<typeof AnalyzeApiResponseCorrectnessOutputSchema>;

export async function analyzeApiResponseCorrectness(input: AnalyzeApiResponseCorrectnessInput): Promise<AnalyzeApiResponseCorrectnessOutput> {
  return analyzeApiResponseCorrectnessFlow(input);
}

const prompt = ai.definePrompt({
  name: 'analyzeApiResponseCorrectnessPrompt',
  input: {schema: AnalyzeApiResponseCorrectnessInputSchema},
  output: {schema: AnalyzeApiResponseCorrectnessOutputSchema},
  prompt: `You are an AI agent specializing in analyzing API responses for correctness, latency, and errors.

  Analyze the following API response and provide a summary of your analysis, including any potential issues.
  Suggest improvements for better error handling, improved test payloads, or missing headers.

  Status Code: {{{statusCode}}}
  Response Time: {{{responseTime}}} ms
  Response Body: {{{responseBody}}}
  ${'{{#if expectedSchema}}'}Expected Schema: {{{expectedSchema}}}${'{{/if}}'}

  Analysis Summary:
  Suggested Improvements:`,
});

const analyzeApiResponseCorrectnessFlow = ai.defineFlow(
  {
    name: 'analyzeApiResponseCorrectnessFlow',
    inputSchema: AnalyzeApiResponseCorrectnessInputSchema,
    outputSchema: AnalyzeApiResponseCorrectnessOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
