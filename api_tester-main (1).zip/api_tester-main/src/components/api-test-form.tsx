'use client';

import { useFieldArray, useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { runAndAnalyzeApiTest } from '@/lib/actions';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import type { TestResult } from '@/lib/types';
import { Bot, Loader, Plus, Send, Trash2 } from 'lucide-react';

const apiTestFormSchema = z.object({
  method: z.string().default('GET'),
  url: z.string().url('Please enter a valid URL.'),
  headers: z.array(
    z.object({
      key: z.string(),
      value: z.string(),
    })
  ),
  body: z.string().refine(
    (val) => {
      if (val.trim() === '') return true;
      try {
        JSON.parse(val);
        return true;
      } catch (e) {
        return false;
      }
    },
    { message: 'Body must be valid JSON or empty.' }
  ).default(''),
});

type ApiTestFormValues = z.infer<typeof apiTestFormSchema>;

interface ApiTestFormProps {
  onTestRun: (result: TestResult | null, error: string | null) => void;
  setIsLoading: (loading: boolean) => void;
  isLoading: boolean;
}

export default function ApiTestForm({ onTestRun, setIsLoading, isLoading }: ApiTestFormProps) {
  const { toast } = useToast();

  const form = useForm<ApiTestFormValues>({
    resolver: zodResolver(apiTestFormSchema),
    defaultValues: {
      method: 'GET',
      url: 'https://dummyjson.com/posts/1',
      headers: [{ key: 'Content-type', value: 'application/json; charset=UTF-8' }],
      body: '',
    },
  });

  const { fields, append, remove } = useFieldArray({
    control: form.control,
    name: 'headers',
  });

  const onSubmit = async (data: ApiTestFormValues) => {
    setIsLoading(true);
    onTestRun(null, null);

    const headersObject = data.headers.reduce((acc, { key, value }) => {
      if (key) acc[key] = value;
      return acc;
    }, {} as Record<string, string>);

    const { result, error } = await runAndAnalyzeApiTest({
      ...data,
      headers: JSON.stringify(headersObject),
    });

    if (error) {
      toast({
        variant: 'destructive',
        title: 'Error',
        description: error,
      });
      onTestRun(null, error);
    } else {
      onTestRun(result, null);
    }

    setIsLoading(false);
  };

  return (
    <Card className="sticky top-8 shadow-lg">
      <CardHeader>
        <div className="flex items-center gap-2">
            <Bot className="h-6 w-6 text-accent"/>
            <CardTitle className="font-headline text-2xl">API Test Agent</CardTitle>
        </div>
        <CardDescription>Enter an API endpoint to run a new test.</CardDescription>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <div className="flex gap-2">
              <FormField
                control={form.control}
                name="method"
                render={({ field }) => (
                  <FormItem className="w-1/3">
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Method" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {['GET', 'POST', 'PUT', 'PATCH', 'DELETE'].map((method) => (
                          <SelectItem key={method} value={method}>
                            {method}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="url"
                render={({ field }) => (
                  <FormItem className="w-2/3">
                    <FormControl>
                      <Input placeholder="https://api.example.com/data" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className="space-y-2">
              <FormLabel>Headers</FormLabel>
              {fields.map((field, index) => (
                <div key={field.id} className="flex gap-2 items-center">
                  <FormField
                    control={form.control}
                    name={`headers.${index}.key`}
                    render={({ field }) => (
                      <FormItem className="flex-1">
                        <FormControl>
                          <Input placeholder="Key" {...field} />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name={`headers.${index}.value`}
                    render={({ field }) => (
                      <FormItem className="flex-1">
                        <FormControl>
                          <Input placeholder="Value" {...field} />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                  <Button type="button" variant="ghost" size="icon" onClick={() => remove(index)}>
                    <Trash2 className="h-4 w-4 text-destructive" />
                  </Button>
                </div>
              ))}
              <Button type="button" variant="outline" size="sm" onClick={() => append({ key: '', value: '' })}>
                <Plus className="mr-2 h-4 w-4" /> Add Header
              </Button>
            </div>

            <FormField
              control={form.control}
              name="body"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Body</FormLabel>
                  <FormControl>
                    <Textarea placeholder='{ "key": "value" }' className="font-code min-h-[120px]" {...field} />
                  </FormControl>
                   <FormMessage />
                </FormItem>
              )}
            />

            <Button type="submit" className="w-full" disabled={isLoading}>
              {isLoading ? (
                <>
                  <Loader className="mr-2 h-4 w-4 animate-spin" />
                  Running Test...
                </>
              ) : (
                <>
                  <Send className="mr-2 h-4 w-4" />
                  Run Test
                </>
              )}
            </Button>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}
