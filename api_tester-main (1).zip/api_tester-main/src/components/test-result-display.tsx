'use client';

import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import type { TestResult } from '@/lib/types';
import { AlertCircle, Bot, BrainCircuit, FileText, Loader, Server, Terminal, Timer, FileJson } from 'lucide-react';
import { Skeleton } from './ui/skeleton';

interface TestResultDisplayProps {
  result: TestResult | null;
  isLoading: boolean;
  error: string | null;
}

const CodeBlock = ({ content }: { content: string }) => {
    let formattedContent = content;
    try {
        const parsed = JSON.parse(content);
        formattedContent = JSON.stringify(parsed, null, 2);
    } catch (e) {
        // Not a JSON string, display as is
    }

    return (
        <pre className="p-4 rounded-md bg-secondary/50 text-secondary-foreground overflow-x-auto text-sm font-code">
            <code>{formattedContent}</code>
        </pre>
    );
}

const AiResponse = ({ icon: Icon, title, children }: { icon: React.ElementType, title: string, children: React.ReactNode}) => (
    <div className="flex items-start gap-4">
        <div className="p-2 rounded-full bg-accent/20 text-accent">
            <Icon className="h-6 w-6" />
        </div>
        <div className="flex-1">
            <h3 className="font-headline text-lg font-semibold">{title}</h3>
            <div className="prose prose-sm text-foreground max-w-none">{children}</div>
        </div>
    </div>
);


const StatusBadge = ({ statusCode }: { statusCode: number }) => {
  const getStatusColor = () => {
    if (statusCode >= 200 && statusCode < 300) return 'bg-green-500';
    if (statusCode >= 400 && statusCode < 500) return 'bg-yellow-500';
    if (statusCode >= 500) return 'bg-red-500';
    return 'bg-gray-500';
  };
  return (
    <Badge className={`text-white hover:text-white ${getStatusColor()}`}>{statusCode}</Badge>
  );
};


export default function TestResultDisplay({ result, isLoading, error }: TestResultDisplayProps) {
    
    if (isLoading) {
        return (
            <Card className="shadow-lg">
                <CardHeader>
                    <Skeleton className="h-8 w-3/4" />
                    <Skeleton className="h-4 w-1/2" />
                </CardHeader>
                <CardContent className="space-y-4">
                    <div className="flex gap-4">
                        <Skeleton className="h-6 w-20 rounded-full" />
                        <Skeleton className="h-6 w-24 rounded-full" />
                    </div>
                    <Skeleton className="h-10 w-full" />
                    <Skeleton className="h-48 w-full" />
                </CardContent>
            </Card>
        )
    }

    if (error && !result) {
        return (
            <Card className="shadow-lg">
                <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-destructive">
                        <AlertCircle /> Test Failed to Run
                    </CardTitle>
                    <CardDescription>An error occurred before the test could complete.</CardDescription>
                </CardHeader>
                <CardContent>
                    <CodeBlock content={error} />
                </CardContent>
            </Card>
        )
    }

    if (!result) {
        return (
          <Card className="shadow-lg flex flex-col items-center justify-center h-full min-h-[400px]">
            <CardHeader className="text-center">
              <div className="mx-auto bg-secondary p-4 rounded-full w-fit">
                <Bot className="h-12 w-12 text-muted-foreground" />
              </div>
              <CardTitle className="mt-4 font-headline text-2xl">Awaiting Test</CardTitle>
              <CardDescription>Run a new test to see the results and AI analysis here.</CardDescription>
            </CardHeader>
          </Card>
        );
    }

    return (
        <Card className="shadow-lg">
            <CardHeader>
            <CardTitle className="font-headline text-2xl truncate">Test Results</CardTitle>
            <CardDescription className="truncate">{result.request.method} {result.request.url}</CardDescription>
            </CardHeader>
            <CardContent>
                <div className="flex flex-wrap gap-2 mb-4">
                    <div className="flex items-center gap-2">
                        <Server className="h-4 w-4 text-muted-foreground" />
                        <StatusBadge statusCode={result.statusCode} />
                    </div>
                    <div className="flex items-center gap-2">
                        <Timer className="h-4 w-4 text-muted-foreground" />
                        <Badge variant="secondary">{result.responseTime}ms</Badge>
                    </div>
                </div>
                <Tabs defaultValue="body">
                    <TabsList>
                        <TabsTrigger value="body">Body</TabsTrigger>
                        <TabsTrigger value="headers">Headers</TabsTrigger>
                        {result.aiAnalysis && <TabsTrigger value="analysis">AI Analysis</TabsTrigger>}
                        {result.aiDocs && <TabsTrigger value="docs">Docs & cURL</TabsTrigger>}
                        {result.aiFailureExplanation && <TabsTrigger value="failure">Failure Explanation</TabsTrigger>}
                    </TabsList>
                    <TabsContent value="body" className="mt-4">
                        <CodeBlock content={result.responseBody} />
                    </TabsContent>
                    <TabsContent value="headers" className="mt-4">
                        <CodeBlock content={JSON.stringify(result.responseHeaders, null, 2)} />
                    </TabsContent>
                    {result.aiAnalysis && (
                         <TabsContent value="analysis" className="mt-4 space-y-6">
                            <AiResponse icon={BrainCircuit} title="Analysis Summary">
                                <p>{result.aiAnalysis.analysisSummary}</p>
                            </AiResponse>
                             <AiResponse icon={FileJson} title="Suggested Improvements">
                                <p>{result.aiAnalysis.suggestedImprovements}</p>
                            </AiResponse>
                         </TabsContent>
                    )}
                    {result.aiDocs && (
                         <TabsContent value="docs" className="mt-4 space-y-6">
                             <AiResponse icon={FileText} title="API Documentation">
                                <p className="whitespace-pre-wrap">{result.aiDocs.documentation}</p>
                            </AiResponse>
                             <AiResponse icon={Terminal} title="cURL Command">
                                <CodeBlock content={result.aiDocs.curlCommand} />
                            </AiResponse>
                         </TabsContent>
                    )}
                    {result.aiFailureExplanation && (
                        <TabsContent value="failure" className="mt-4">
                             <AiResponse icon={AlertCircle} title="AI Failure Explanation">
                                <p>{result.aiFailureExplanation.explanation}</p>
                            </AiResponse>
                        </TabsContent>
                    )}
                </Tabs>
            </CardContent>
        </Card>
    );
}
